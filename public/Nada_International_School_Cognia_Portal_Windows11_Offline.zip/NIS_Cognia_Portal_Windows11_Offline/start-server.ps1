$port = 3000
$path = $PSScriptRoot

Write-Host "==========================================================" -ForegroundColor Green
Write-Host "  Nada International School Cognia Portal - Windows 11" -ForegroundColor Yellow
Write-Host "==========================================================" -ForegroundColor Green
Write-Host "Local offline server running at: http://localhost:$port" -ForegroundColor Cyan
Write-Host "Keep this window open while using the portal." -ForegroundColor Gray
Write-Host "To stop the server, press Ctrl+C or close this window." -ForegroundColor Gray
Write-Host ""

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
try {
    $listener.Start()
} catch {
    $port = 3001
    Write-Host "Port 3000 in use, switching to http://localhost:$port" -ForegroundColor Yellow
    $listener = New-Object System.Net.HttpListener
    $listener.Prefixes.Add("http://localhost:$port/")
    $listener.Start()
}

# Launch Edge in app mode, Chrome in app mode, or default browser
try {
    Start-Process "msedge.exe" -ArgumentList "--app=http://localhost:$port" -ErrorAction Stop
} catch {
    try {
        Start-Process "chrome.exe" -ArgumentList "--app=http://localhost:$port" -ErrorAction Stop
    } catch {
        Start-Process "http://localhost:$port"
    }
}

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response
        
        $rawPath = $request.Url.LocalPath.TrimStart('/')
        if ([string]::IsNullOrEmpty($rawPath)) { $rawPath = "index.html" }
        $filePath = Join-Path $path $rawPath
        
        if (-not (Test-Path $filePath -PathType Leaf)) {
            $filePath = Join-Path $path "index.html"
        }

        if (Test-Path $filePath -PathType Leaf) {
            $content = [System.IO.File]::ReadAllBytes($filePath)
            $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
            switch ($ext) {
                ".html" { $response.ContentType = "text/html; charset=utf-8" }
                ".js"   { $response.ContentType = "application/javascript; charset=utf-8" }
                ".mjs"  { $response.ContentType = "application/javascript; charset=utf-8" }
                ".css"  { $response.ContentType = "text/css; charset=utf-8" }
                ".json" { $response.ContentType = "application/json; charset=utf-8" }
                ".svg"  { $response.ContentType = "image/svg+xml" }
                ".png"  { $response.ContentType = "image/png" }
                ".jpg"  { $response.ContentType = "image/jpeg" }
                ".jpeg" { $response.ContentType = "image/jpeg" }
                ".ico"  { $response.ContentType = "image/x-icon" }
                ".pdf"  { $response.ContentType = "application/pdf" }
                ".mp3"  { $response.ContentType = "audio/mpeg" }
                ".wav"  { $response.ContentType = "audio/wav" }
                ".ogg"  { $response.ContentType = "audio/ogg" }
                ".mp4"  { $response.ContentType = "video/mp4" }
                ".webm" { $response.ContentType = "video/webm" }
                Default { $response.ContentType = "application/octet-stream" }
            }
            $response.Headers.Add("Access-Control-Allow-Origin", "*")
            $response.ContentLength64 = $content.Length
            $response.OutputStream.Write($content, 0, $content.Length)
        } else {
            $response.StatusCode = 404
        }
        $response.OutputStream.Close()
    } catch {
        # continue loop on client abort
    }
}
