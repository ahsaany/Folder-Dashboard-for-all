@echo off
cd /d "%~dp0source"
title Nada International School Cognia Portal - Node.js Server
cls
echo Checking Node.js environment...
where npm >nul 2>nul
if %errorlevel% neq 0 (
    echo [NOTE] Node.js is not found.
    echo Launching via native Windows 11 launcher instead...
    cd /d "%~dp0"
    call RUN_OFFLINE_PORTAL.bat
    exit /b
)

if not exist node_modules (
    echo Installing dependencies (first run only)...
    call npm install
)

echo Starting development server on http://localhost:3000 ...
start "" http://localhost:3000
call npm run dev
pause
