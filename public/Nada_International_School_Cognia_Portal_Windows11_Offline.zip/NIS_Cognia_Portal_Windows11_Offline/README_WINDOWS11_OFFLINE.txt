=============================================================================
  NADA INTERNATIONAL SCHOOL - COGNIA ACCREDITATION PORTAL
  WINDOWS 11 OFFLINE DESKTOP DEPLOYMENT GUIDE
=============================================================================

[URDU GUIDE / اردو ہدایات]:
Yeh software mukammal taur par OFFLINE chalanay ke liye tayyar hai.
Isay chalanay ke liye internet ki bilkul zaroorat nahi hai.

STEP 1: Is ZIP file ko kisi bhi folder mein EXTRACT karein 
        (e.g., C:\NIS_Cognia_Portal ya Desktop par).
STEP 2: Folder ke andar "RUN_OFFLINE_PORTAL.bat" par DOUBLE CLICK karein.
STEP 3: Ek black command window open hogi aur Microsoft Edge khud ba khud 
        http://localhost:3000 par Desktop App mode mein open ho jayega!
STEP 4: Black window ko minimize kar lein, band mat karein jab tak app use karni ho.

Tamam 35 folders, evidence documents, PDFs, aur 5 Stars ratings aapke computer 
ki local IndexedDB storage mein permanently save rahenge!

-----------------------------------------------------------------------------
[ENGLISH GUIDE]:
HOW TO RUN THIS SOFTWARE ON WINDOWS 11 WITHOUT INTERNET:

METHOD 1: 1-CLICK LAUNCHER (ZERO INSTALLATION NEEDED)
1. Extract this entire ZIP archive to a folder on your Windows 11 PC 
   (e.g., C:\NIS_Cognia_Portal or your Desktop).
2. Double-click "RUN_OFFLINE_PORTAL.bat".
3. A Windows 11 desktop window will open immediately on http://localhost:3000.
   - Powered by the built-in Windows PowerShell HTTP engine.
   - Zero internet or Node.js installation required.
   - All uploaded evidence PDFs and folders are permanently saved in your computer's 
     local IndexedDB storage.

METHOD 2: INSTALL AS A WINDOWS 11 APP VIA MICROSOFT EDGE OR CHROME
1. While the portal is open in Microsoft Edge or Google Chrome:
2. Look at the address bar on the right side for the "App available" or "Install" icon, 
   OR click the browser menu (...) -> Apps -> "Install this site as an app".
3. Click "Install".
4. Check "Pin to taskbar" and "Pin to Start".
5. You now have a native Windows 11 desktop shortcut with the NIS school crest icon!

METHOD 3: RUNNING WITH NODE.JS / NPM (DEVELOPER MODE)
If you have Node.js installed:
1. Double-click "RUN_WITH_NODEJS.bat".
2. It automatically installs dependencies in the 'source' directory and starts the Vite server.

Support & Accreditation Contact:
Nada International School Accreditation Committee
Cognia Performance Standards Portal
=============================================================================
