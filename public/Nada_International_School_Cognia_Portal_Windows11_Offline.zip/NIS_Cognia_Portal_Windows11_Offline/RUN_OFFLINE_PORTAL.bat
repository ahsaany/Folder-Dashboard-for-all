@echo off
cd /d "%~dp0"
title Nada International School Cognia Portal - Windows 11 Launcher
cls
echo =========================================================================
echo    Nada International School Cognia Portal - Windows 11 Offline Engine
echo =========================================================================
echo.
echo Starting local offline server on http://localhost:3000 ...
echo Opening in desktop application window...
echo.
echo (Keep this command window open while using the application)
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-server.ps1"
if %errorlevel% neq 0 (
    echo.
    echo [NOTE] PowerShell server interrupted. Trying Python fallback server...
    python -m http.server 3000 || py -m http.server 3000
)
pause
