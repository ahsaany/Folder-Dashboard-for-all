@echo off
cd /d "%~dp0"
title Nada International School Cognia Portal - Python Server
cls
echo Starting local offline server with Python on http://localhost:3000 ...
start "" http://localhost:3000
python -m http.server 3000 || py -m http.server 3000
pause
